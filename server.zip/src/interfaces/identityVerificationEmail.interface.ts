export interface IIdentityVerificationEmailData {
  name: string;
  email: string;
}
