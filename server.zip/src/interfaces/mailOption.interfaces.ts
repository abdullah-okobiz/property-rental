export interface IMailOption {
  from: string;
  to: string;
  subject: string;
  html: string;
}
