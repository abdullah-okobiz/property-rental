const VissionMiddlewares = {};

export default VissionMiddlewares;
