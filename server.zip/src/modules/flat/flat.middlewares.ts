const FlatMiddlewares = {};

export default FlatMiddlewares;
