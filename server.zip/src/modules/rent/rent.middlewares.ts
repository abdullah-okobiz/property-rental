const RentMiddlewares = {};

export default RentMiddlewares;
