const FaqMiddlewares = {};

export default FaqMiddlewares;
