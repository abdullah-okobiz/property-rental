const CategoryMiddlewares = {};

export default CategoryMiddlewares;
