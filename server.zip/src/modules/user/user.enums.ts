export enum DocumentType{
    NID="nid",
    DRIVING_LICENSE='drivingLicense',
    PASSPORT='passport'
}