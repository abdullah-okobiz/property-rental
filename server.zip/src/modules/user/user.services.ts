import redisClient from "../../configs/redis.configs";
import { join } from "path";
import { promises as fs } from "fs";
import { TokenPayload } from "../../interfaces/jwtPayload.interfaces";
import {
  generateAccessToken,
  generateRefreshToken,
} from "../../utils/jwt.utils";
import sendVerificationEmail from "../../utils/sendVerificationEmail.utils";
import {
  ISignupPayload,
  IUser,
  ITokenProcessReturn,
  IProcessDeleteUserPayload,
  IProcessResendEmailPayload,
  IIdentityDocument,
  IFindStaffRequestQuery,
  IFindStaffQuery,
  IUserPayload,
} from "./user.interfaces";
import UserRepositories from "./user.repositories";
import otpGenerator from "otp-generator";

const {
  createUser,
  verifyUser,
  deleteUser,
  createStaff,
  deleteStaff,
  findAllStaff,
  changeStaffPassword,
  changeStaffRole,
} = UserRepositories;
const UserServices = {
  processSignup: async (payload: ISignupPayload) => {
    try {
      const createdUser = await createUser(payload);
      const otp = otpGenerator.generate(5, {
        digits: true,
        lowerCaseAlphabets: false,
        specialChars: false,
        upperCaseAlphabets: false,
      });
      await redisClient.set(
        `user:profile:${createdUser._id}`,
        JSON.stringify(createdUser),
        "EX",
        86400
      );
      await redisClient.set(`user:otp:${createdUser.email}`, otp, "EX", 2 * 60);
      await sendVerificationEmail({
        email: createdUser.email,
        expirationTime: 2,
        name: createdUser.name,
        otp,
      });
      return createdUser;
    } catch (error) {
      if (error instanceof Error) {
        throw error;
      } else {
        throw new Error("Unknown Error Occurred In Signup Service");
      }
    }
  },
  processVerify: async (email: string): Promise<ITokenProcessReturn | null> => {
    const data = await verifyUser(email);
    try {
      if (data) {
        const { email, isVerified, role, id, name, accountStatus } = data;
        const accessToken = generateAccessToken({
          email,
          isVerified,
          role,
          userId: id,
          name,
          accountStatus,
        }) as string;
        const refreshToken = generateRefreshToken({
          email,
          isVerified,
          role,
          userId: id,
          name,
          accountStatus,
        }) as string;

        return { accessToken, refreshToken } as ITokenProcessReturn;
      }
      return null;
    } catch (error) {
      if (error instanceof Error) {
        throw error;
      } else {
        throw new Error("Unknown Error Occurred In verify user service");
      }
    }
  },
  processLogin: (payload: IUser): ITokenProcessReturn => {
    const { email, isVerified, role, id, name, accountStatus } = payload;
    const accessToken = generateAccessToken({
      email,
      isVerified,
      role,
      userId: id,
      name,
      accountStatus,
    }) as string;
    const refreshToken = generateRefreshToken({
      email,
      isVerified,
      role,
      userId: id,
      name,
      accountStatus,
    }) as string;

    return { accessToken, refreshToken } as ITokenProcessReturn;
  },
  processTokens: (payload: TokenPayload): ITokenProcessReturn => {
    const { email, isVerified, role, userId, name, accountStatus } = payload;

    const accessToken = generateAccessToken({
      email,
      isVerified,
      role,
      userId,
      name,
      accountStatus,
    }) as string;

    const refreshToken = generateRefreshToken({
      email,
      isVerified,
      role,
      userId,
      name,
      accountStatus,
    }) as string;

    return { accessToken, refreshToken } as ITokenProcessReturn;
  },
  processLogout: async (payload: string) => {
    try {
      await redisClient.set(`blacklist:${payload}`, payload);
    } catch (error) {
      throw error;
    }
  },
  processDeleteUser: async ({ id }: IProcessDeleteUserPayload) => {
    try {
      const { deletedIdentityData, deletedUserData } = await deleteUser(id);
      if (!deletedUserData) return false;
      if (deletedIdentityData) {
        const { frontSide, backSide } =
          deletedIdentityData as IIdentityDocument;
        const images = [frontSide, backSide];
        const relativeImagePath = images?.map((item) =>
          item?.replace("/public/", "")
        );
        const filePaths = relativeImagePath?.map((item) =>
          join(__dirname, "../../../public", item!)
        );
        await Promise.all([filePaths?.map((item) => fs.unlink(item))]);
      }
      return true;
    } catch (error) {
      throw error;
    }
  },
  processResend: async ({ email, name }: IProcessResendEmailPayload) => {
    try {
      const otp = otpGenerator.generate(5, {
        digits: true,
        lowerCaseAlphabets: false,
        specialChars: false,
        upperCaseAlphabets: false,
      });
      await redisClient.set(`user:otp:${email}`, otp, "EX", 2 * 60);
      await sendVerificationEmail({
        email: email,
        expirationTime: 2,
        name: name,
        otp,
      });
    } catch (error) {
      if (error instanceof Error) {
        throw error;
      } else {
        throw new Error("Unknown Error Occurred In Resend Otp Operation");
      }
    }
  },
  processFindAllStaff: async ({
    page,
    role,
    search,
  }: IFindStaffRequestQuery) => {
    try {
      const query: IFindStaffQuery = { isStaff: true };
      if (typeof search === "string" && search.trim() !== "") {
        query.email = { $regex: search.trim(), $options: "i" };
      }
      if (role) query.role = role;
      return await findAllStaff({ query, page });
    } catch (error) {
      if (error instanceof Error) {
        throw error;
      } else {
        throw new Error("Unknown Error Occurred In Find All Staff Service");
      }
    }
  },
  processCreateStaff: async (payload: ISignupPayload) => {
    try {
      return await createStaff(payload);
    } catch (error) {
      if (error instanceof Error) {
        throw error;
      } else {
        throw new Error("Unknown Error Occurred In Staff Creation Service");
      }
    }
  },
  processChangeStaffPassword: async (payload: IUserPayload) => {
    try {
      return await changeStaffPassword(payload);
    } catch (error) {
      if (error instanceof Error) {
        throw error;
      } else {
        throw new Error(
          "Unknown Error Occurred In Staff Password Change Service"
        );
      }
    }
  },
  processChangeStaffRole: async (payload: IUserPayload) => {
    try {
      return await changeStaffRole(payload);
    } catch (error) {
      if (error instanceof Error) {
        throw error;
      } else {
        throw new Error("Unknown Error Occurred In Staff role Change Service");
      }
    }
  },
  processDeleteStaff: async ({ id }: IProcessDeleteUserPayload) => {
    try {
      const { deletedUserData } = await deleteStaff(id);
      if (!deletedUserData) return false;
      return true;
    } catch (error) {
      if (error instanceof Error) {
        throw error;
      } else {
        throw new Error("Unknown Error Occurred In Staff Delete Service");
      }
    }
  },
};

export default UserServices;
