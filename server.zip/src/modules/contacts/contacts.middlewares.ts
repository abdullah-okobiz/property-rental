const ContactsMiddlewares = {};

export default ContactsMiddlewares;
