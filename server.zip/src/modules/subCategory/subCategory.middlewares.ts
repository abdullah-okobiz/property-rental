const SubCategoryMiddlewares = {};

export default SubCategoryMiddlewares;
