const FeatureMiddlewares = {};
export default FeatureMiddlewares;
