const AboutUsMiddlewares = {};

export default AboutUsMiddlewares;
