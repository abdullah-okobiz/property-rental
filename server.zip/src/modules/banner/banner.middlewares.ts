const BannerMiddlewares = {};

export default BannerMiddlewares;
