const LandMiddlewares = {};

export default LandMiddlewares;
